package com.bugalho.footdream.ui.launch;

import androidx.lifecycle.ViewModel;

public class LaunchViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}

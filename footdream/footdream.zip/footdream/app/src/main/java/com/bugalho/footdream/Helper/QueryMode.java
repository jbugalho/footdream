package com.bugalho.footdream.Helper;

public enum QueryMode {
    WRITE,
    READ
}
package com.bugalho.footdream.Helper;

import java.sql.ResultSet;

public interface OnDatabaseBuilderQueryExecuteListener {
    void OnGetResultHandler(Object resultSet);
}

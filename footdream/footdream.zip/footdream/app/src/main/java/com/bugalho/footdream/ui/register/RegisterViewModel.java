package com.bugalho.footdream.ui.register;

import androidx.lifecycle.ViewModel;

public class RegisterViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
